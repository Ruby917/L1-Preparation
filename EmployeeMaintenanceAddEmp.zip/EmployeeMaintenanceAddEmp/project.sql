//User_master

delete user_master where userid=202; 

truncate table user_master;

drop table user_master;

select * from user_master;

create table User_Master 
(UserId varchar2(6),
UserName varchar2(25) NOT NULL,
UserPassword varchar2(50) NOT NULL,
UserType varchar2(10) NOT NULL,
Constraint pk_user Primary key(UserId));

insert into User_Master values(user_seq.nextval,'ruby@capge.com','ruby123','employee');
insert into User_Master values('202','riya@capge.com','riya23','admin');
insert into User_Master values('203','saras@capge.com','saras123','employee');
insert into User_Master values('204','vandu@capge.com','vandu123','employee');
insert into User_Master values('205','shikha@capge.com','shikha123','employee');
insert into User_Master values('206','ruchi@capge.com','ruchi123','employee');
insert into User_Master values('207','ranju@capge.com','ranju123','admin');
insert into User_Master values('208','payal@capge.com','payal123','employee');
insert into User_Master values('209','pooja@capge.com','pooja123','employee');
insert into User_Master values('210','anita@capge.com','anita123','employee');

create sequence hibernate_sequence start with 100000 increment by 1;

drop sequence user_seqe;

drop sequence hibernate_sequence;


commit

//Department

select * from department;

truncate table department;

Create table Department
(Dept_ID int,
Dept_Name varchar2(50),
Constraint pk_dept primary key(Dept_ID));

insert into DEPARTMENT values(1,'IT');
insert into DEPARTMENT values(2,'Finance');
insert into DEPARTMENT values(3,'Hr');
insert into DEPARTMENT values(4,'HelpDesk');

//Grade_master

select * from grade_master;

truncate table grade_master;

create table Grade_Master
(Grade_Code varchar2(2),
Description varchar2(50),
Min_Salary int,
Max_Salary int,
Constraint pk_grade primary key(grade_code));

insert into grade_master values('M1','Associate Software Developer',20000,25000);
insert into grade_master values('M2','Senior Software Developer',25001,30000);
insert into grade_master values('M3','Associate Software Tester',30001,35000);
insert into grade_master values('M4','Senior Software Tester',35001,45000);
insert into grade_master values('M5','Team Lead',45001,55000);
insert into grade_master values('M6','Manager',55001,65000);
insert into grade_master values('M7','Senior Manager',65001,75000);

drop table grade_Master cascade constraints;

//Employee
SELECT * FROM EMPLOYEE;

DROP TABLE EMPLOYEE CASCADE constraint;

delete employee where emp_id=201;

create table Employee
(Emp_ID varchar2(6),
Emp_First_Name varchar2(25),
Emp_Last_Name VARCHAR2(25),
Emp_Date_of_Birth Date,
Emp_Date_of_Joining Date,
Emp_Dept_ID int,
Emp_Grade varchar2(2),
Emp_Designation varchar2(50),
Emp_Basic int,
Emp_Gender varchar2(10),
Emp_Marital_Status varchar2(10),
Emp_Home_Address varchar2(100),
Emp_Contact_num varchar2(15),
Constraint pk_emp Primary key(emp_id));
Constraint fk_grade FOREIGN KEY(Emp_Grade) REFERENCES Grade_Master(Grade_Code), 
Constraint fk_dept FOREIGN KEY(Emp_Dept_ID) REFERENCES Department(Dept_ID));

Constraint fk_user FOREIGN KEY(Emp_ID) REFERENCES User_Master(UserId)

truncate table employee;

update Employee set emp_gender='Female' where emp_id=1001;

insert into employee values("10000001",'Ruby','Singh','01-Sep-1994','18-Jan-17','Female','CC','SoftWare Engineer',8000,'Female','Single','Mumbai',8691916204);
insert into employee values('100001','Saraswati','Jeswani','21-Mar-1995','12-Feb-12',4,'M4','SoftWare Engineer',20000,'Female','Married','Pune-98',9328716432);
insert into employee values(1003,'Vandana','Nagpal','17-May-1994','13-Jan-10',3,'BB','SoftWare Analyst',6000,'Male','Divorced','Bangalore',8692955217);
insert into employee values(1004,'Shikha','Pandey','12-Feb-1991','14-Jan-11',4,'CC','Consultant',7000,'Female','Separated','Chennai',8652423242);
insert into employee values(1005,'Pooja','Pal','10-Oct-1997','15-Jan-13',1,'AA','Senior Consultant',9000,'Male','Single','Mumbai',8691917654);
insert into employee values(1006,'Deepika','Chourasiya','25-Apr-1990','16-Jan-14',2,'BB','SoftWare Engineer',10000,'Male','Divorced','Pune',8743916204);
insert into employee values(1007,'Amruta','Patil','21-Nov-1993','17-Jan-15',3,'CC','CA',7000,'Female','Widowed ','Bangalore',8691763404);
insert into employee values(1008,'Ruchi','Bhuta','09-Nov-1994','18-Jan-09',4,'AA','SoftWare Engineer',12000,'Male','Married','Chennai',8643216204);
insert into employee values(1009,'Nivedita','Singh','16-Dec-1987','19-Jan-05',1,'BB','Consultant',11000,'Female','Single','Mumbai',8691543204);
insert into employee values(1010,'Pratiksha','nakti','13-Jun-1989','20-Jan-01',2,'CC','SoftWare Analyst',9000,'Male','Divorced','Pune',8273916204);
insert into employee values(1011,'Jaini','Parikh','10-Aug-1994','21-Jan-14',3,'AA','Senior Consultant',12000,'Female','Married','Chennai',9681916204);
insert into employee values(1012,'Vandana','Yadav','05-Oct-1998','22-Jan-11',4,'BB','SoftWare Engineer',15000,'Male','Separated','Bangalore',9021916204);

INSERT INTO EMPLOYEE VALUES('100001','Ruby','Singh','01-Sep-1994','18-Jan-2017',4,'M4','SoftWare Engineer',20000,'Female','Married','Pune-98',9328716432)

drop sequence hibernate_sequence;

