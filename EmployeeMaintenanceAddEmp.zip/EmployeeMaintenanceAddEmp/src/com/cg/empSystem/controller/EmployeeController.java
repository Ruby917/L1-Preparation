package com.cg.empSystem.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;
import com.cg.empSystem.service.EmployeeService;

@Controller
public class EmployeeController {
	
	private EmployeeService eService;
	private List<String> deptName; 
    private List<String> gender;
    private List<String> grade;
    private List<String> maritalStatus;
    
    private static String salaryMsg;
    private static String ageCheckMsg;
    private static String dojCheckMsg;
	
	@Resource(name="empService")
	public void setEmpService(EmployeeService eService){
		this.eService= eService;
	}
	
	@PostConstruct
	public void initialize() throws EmployeeException{
		deptName = eService.getDeptname();
		
		gender = new ArrayList<String>();
		gender.add("Male");
		gender.add("Female");
		
		grade = new ArrayList<String>();
		grade.add("M1");
		grade.add("M2");
		grade.add("M3");
		grade.add("M4");
		grade.add("M5");
		grade.add("M6");
		grade.add("M7");
		
		maritalStatus = new ArrayList<String>();
		maritalStatus.add("Single");
		maritalStatus.add("Married");
		maritalStatus.add("Divorced");
		maritalStatus.add("Separated");
		maritalStatus.add("Widowed ");
	}
	
	@RequestMapping("addEmpForm")
	public ModelAndView addEmpForm(){
		ModelAndView model = new ModelAndView("addEmployee");
		model.addObject("empDetails", new Employee());
		model.addObject("deptNmList", deptName);
		model.addObject("genderList", gender);
		model.addObject("gradeList", grade);
		model.addObject("maritalStatusList", maritalStatus);
		return model;
	}
	
	@RequestMapping("addEmp")
	public ModelAndView successAdd(@ModelAttribute("empDetails") @Valid Employee emp,BindingResult result) throws ParseException{
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()){
			model = new ModelAndView("addEmployee");
			model.addObject("empDetails", emp);
			model.addObject("deptNmList", deptName);
			model.addObject("genderList", gender);
			model.addObject("gradeList", grade);
			model.addObject("maritalStatusList", maritalStatus);
			return model;
		}
		try {
			
			boolean chkDiffBetDobAndDojStatus = this.checkJoiningDate(emp);
			boolean chkAgeStatus = this.checkAge(emp);
			boolean chkSalStatus = this.checkSalaryRange(model,emp);
						
			if(chkDiffBetDobAndDojStatus && chkAgeStatus && chkSalStatus){
				UserMaster userDetails = eService.addUser(emp);
				model.setViewName("success");
				model.addObject("userDetails", userDetails);
				return model;
			}else{
				model.setViewName("addEmployee");
				model.addObject("empDetails", emp);
				model.addObject("deptNmList", deptName);
				model.addObject("genderList", gender);
				model.addObject("gradeList", grade);
				model.addObject("maritalStatusList", maritalStatus);
				model.addObject("joinDateOfEmployee", dojCheckMsg);
				model.addObject("ageofEmployee", ageCheckMsg);
				model.addObject("salaryRange", salaryMsg);
			}
	        
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("msg", "Record Insertion Failed:"+e.getMessage());
			return model;
		}
		return model;
	}
	
	private boolean checkAge(Employee emp) throws ParseException{
		java.sql.Date dob = emp.getEmpDateOfBirth();
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String dobStr = df.format(dob);
		Calendar calDob = Calendar.getInstance();
		calDob.setTime(df.parse(dobStr));
		
		Calendar today = Calendar.getInstance();
        int curYear = today.get(Calendar.YEAR);
        int dobYear = calDob.get(Calendar.YEAR);
        int age = curYear - dobYear;

        int curMonth = today.get(Calendar.MONTH);
        int dobMonth = calDob.get(Calendar.MONTH);
        if (dobMonth > curMonth) {
            age--;
        } else if (dobMonth == curMonth) {
            int curDay = today.get(Calendar.DAY_OF_MONTH);
            int dobDay = calDob.get(Calendar.DAY_OF_MONTH);
            if (dobDay > curDay) { 
                age--;
            }
       }
        if(age>=18 && age<=58){
        	ageCheckMsg = "";
        	return true;
        }else{
        	ageCheckMsg = "Age Criteria  is 18-58 years";
        	return false;
        }
	}
	
	private boolean checkJoiningDate(Employee emp) throws ParseException{
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd");
		java.sql.Date dob = emp.getEmpDateOfBirth();
		String dobStr = df1.format(dob);
		Calendar calDob = Calendar.getInstance();
		calDob.setTime(df1.parse(dobStr));
        int dobYear = calDob.get(Calendar.YEAR);

        SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
		java.sql.Date doj = emp.getEmpDateOfJoining();
		String dojStr = df2.format(doj);
		Calendar calDoj = Calendar.getInstance();
		calDoj.setTime(df2.parse(dojStr));
        int dojYear = calDoj.get(Calendar.YEAR);

        int diffBetDobAndDoj = dojYear - dobYear;
        
        int dojMonth = calDoj.get(Calendar.MONTH);
        int dobMonth = calDob.get(Calendar.MONTH);
        if (dobMonth > dojMonth) {
        	diffBetDobAndDoj--;
        } else if (dobMonth == dojMonth) {
            int dojDay = calDoj.get(Calendar.DAY_OF_MONTH);
            int dobDay = calDob.get(Calendar.DAY_OF_MONTH);
            if (dobDay > dojDay) { 
            	diffBetDobAndDoj--;
            }
       }
        if(diffBetDobAndDoj>=18){
        	dojCheckMsg = "";
        	return true;
        }else{
        	dojCheckMsg = "Invalid Date of Joining";
        	return false;
        }
	}
	
	private boolean checkSalaryRange(ModelAndView model,Employee emp) {
		boolean status = false;
		try {
			String empGrade = emp.getEmpGrade();
			Grade gradeDetails = eService.getGradeDetails(empGrade);
			
			String gradeCode = gradeDetails.getGradeCode();
			long minSal = Long.parseLong(gradeDetails.getGradeMinSalary());
			long maxSal = Long.parseLong(gradeDetails.getGradeMaxsalary());
			
			long salary = Long.parseLong(emp.getEmpBasic());
					
			if(salary>=minSal && salary<=maxSal){
				salaryMsg ="";
				status = true;
			}else{
				salaryMsg = "Salary should be between "+minSal+" and "+maxSal+" for "+gradeCode;
				status = false;
			}
		} catch (NumberFormatException e) {
			model.setViewName("error");
			model.addObject("msg", "Salary is not in proper format"+e.getMessage());
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("msg", "Checking Salary Range failed"+e.getMessage());
		}
		return status;
	}

	@RequestMapping("getChangedPassForm")
	public ModelAndView getEmployeeIdForm(){
		ModelAndView model = new ModelAndView("getChangedPassForm");
		model.addObject("userDetails", new UserMaster());
		return model;
	}
	
	@RequestMapping("changePass")
	public ModelAndView getChangedPass(@ModelAttribute("userDetails") @Valid UserMaster user,@RequestParam("newPass") String newPass,@RequestParam("confirmPass") String confirmPass,BindingResult result){
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()){
			model = new ModelAndView("getChangedPassForm");
			model.addObject("userDetails", user);
			return model;
		}
		try {
			UserMaster usermstr = eService.getUserDetails(user.getUserId());
			if(user.getUserPassword().equals(usermstr.getUserPassword())){
				if(newPass.equals(confirmPass)){
					usermstr.setUserPassword(newPass);
					UserMaster usermstrnew = eService.changePassword(usermstr);
					System.out.println("After Change password:"+usermstrnew);
					model.setViewName("successChangePass");
					model.addObject("userDetails", usermstrnew);
				}else{
					model.setViewName("getChangedPassForm");
					model.addObject("confirmPassErr", "Confirm Password And New password should be same");
				}
			}else{
				model.setViewName("getChangedPassForm");
				model.addObject("oldPassErr", "Old Password is not Correct");
			}
			
		} catch (EmployeeException e) {
			model.setViewName("error");
			model.addObject("msg", "Password change failed"+e.getMessage());
		}
		return model;
	}
	
	
	
	
	


}
