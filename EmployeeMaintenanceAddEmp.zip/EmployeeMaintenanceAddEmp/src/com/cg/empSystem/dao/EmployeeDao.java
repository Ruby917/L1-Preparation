package com.cg.empSystem.dao;

import java.util.List;

import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;

public interface EmployeeDao {
	UserMaster addUser(Employee emp) throws EmployeeException;
	List<String> getDeptname() throws EmployeeException;
	public UserMaster getUserDetails(String userId) throws EmployeeException;
	UserMaster changePassword(UserMaster user) throws EmployeeException;
	Grade getGradeDetails(String empGrade) throws EmployeeException;
}
