package com.cg.empSystem.dao;

import java.util.List;
import java.util.Random;
import java.security.SecureRandom;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.RollbackException;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;

@Repository("empDao")
public class EmployeeDaoImpl implements EmployeeDao{
	
	@PersistenceContext
	private EntityManager manager;
	
	//Add new  User

	@Override
	public UserMaster addUser(Employee emp) throws EmployeeException {
		UserMaster usermaster = new UserMaster();
		try{
			String userId=usermaster.getUserId();
			
			String userPwd = this.generateRandomPassword();
			String userNm = this.generateUserName(emp);	
			usermaster.setUserId(userId);
			usermaster.setUserName(userNm);
			usermaster.setUserPassword(userPwd);
			usermaster.setUserType("Employee");
			manager.persist(usermaster);
			manager.flush();
			
			String empId = usermaster.getUserId();
			emp.setEmpId(empId);
			this.addEmp(emp);
		}catch(RollbackException rl){
			throw new EmployeeException("User duplicated",rl);
		}
		return usermaster;
	}
	
	public Employee addEmp(Employee emp) throws EmployeeException {
		try {
			String deptName = emp.getDeptName();
			Department dept = this.getDeptId(deptName);
			dept.setDeptId(dept.getDeptId());
			emp.setEmpDeptId(dept.getDeptId());
			
			manager.persist(emp);
			manager.flush();
		} catch (RollbackException rl) {
			throw new EmployeeException("Employee duplicated",rl);
		}
		return emp;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getDeptname() throws EmployeeException {
		List<String> deptNmList;
		try {
			Query qry = manager.createQuery("select d.deptName from department as d");
			deptNmList = qry.getResultList();
		} catch (Exception e) {
			throw new EmployeeException("Improper query fabrication",e);
		}
		return deptNmList;
	}
	
	public Department getDeptId(String deptName) throws EmployeeException {
		Department dept = null;
		try {
			TypedQuery<Department> qry = manager.createNamedQuery("getdeptId",Department.class);
			qry.setParameter("dName", deptName);
			dept = qry.getSingleResult();
		} catch (Exception e) {
			throw new EmployeeException("Improper query fabrication",e);
		}
		return dept;
	}
	
	private static final Random RANDOM = new SecureRandom();
	public static final int PASSWORD_LENGTH = 8;
	
	public String generateRandomPassword(){
	      String letters = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ0123456789";

	      String pw = "";
	      for (int i=0; i<PASSWORD_LENGTH; i++)
	      {
	          int index = (int)(RANDOM.nextDouble()*letters.length());
	          pw += letters.substring(index, index+1);
	      }
	      return pw;
	  }
	
	public String generateUserName(Employee emp){
		String userName = null;		
		String fName = emp.getEmpFname();
		if(fName.length()>=6){
			int a = (int) (Math.random()*100);
			userName = fName.substring(0,6)+"."+a+"@capgemini.com";
		}else{
			int a = (int) (Math.random()*100);
			userName = fName.toLowerCase()+"."+a+"@capgemini.com";
		}
		return userName;
	}
	
	@Override
	public Grade getGradeDetails(String empGrade) throws EmployeeException {
		Grade grade = new Grade();
		try {
			grade = manager.find(Grade.class, empGrade);
		} catch (RollbackException rl) {
			throw new EmployeeException("Grade does not exist",rl);
		}
		return grade;
	}
	//End of Add New User
	
	//Change Password
	
	@Override
	public UserMaster getUserDetails(String userId) throws EmployeeException {
		UserMaster user = new UserMaster();
		try {
			user = manager.find(UserMaster.class, userId);
		} catch (RollbackException rl) {
			throw new EmployeeException("Employee does not exist",rl);
		}
		return user;
	}
	
	@Override
	public UserMaster changePassword(UserMaster user) throws EmployeeException {
		try {
			manager.merge(user);
		} catch (RollbackException rl) {
			throw new EmployeeException("Employee does not exist",rl);
		}
		return user;
	}

	
	
	
	
	
	
}
