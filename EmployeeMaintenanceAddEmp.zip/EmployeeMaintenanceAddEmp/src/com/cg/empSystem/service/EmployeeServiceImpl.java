package com.cg.empSystem.service;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.empSystem.dao.EmployeeDao;
import com.cg.empSystem.dto.Department;
import com.cg.empSystem.dto.Employee;
import com.cg.empSystem.dto.Grade;
import com.cg.empSystem.dto.UserMaster;
import com.cg.empSystem.exception.EmployeeException;

@Transactional
@Service("empService")
public class EmployeeServiceImpl implements EmployeeService{

	private EmployeeDao empDao;
	
	@Resource(name="empDao")
	public void setEmpDao(EmployeeDao empDao){
		this.empDao = empDao;
	}
	
	@Override
	public UserMaster addUser(Employee emp) throws EmployeeException {
		return empDao.addUser(emp);
	}

	@Override
	public List<String> getDeptname() throws EmployeeException {
		return empDao.getDeptname();
	}
	
	@Override
	public UserMaster getUserDetails(String userId) throws EmployeeException {
		return empDao.getUserDetails(userId);
	}

	@Override
	public UserMaster changePassword(UserMaster user) throws EmployeeException {
		return empDao.changePassword(user);
	}

	@Override
	public Grade getGradeDetails(String empGrade) throws EmployeeException {
		return empDao.getGradeDetails(empGrade);
	}
}
