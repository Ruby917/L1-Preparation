package com.cg.empSystem.dto;



import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;
@Entity(name="grade")
@Table(name="Grade_Master")
public class Grade {

	private String gradeCode;
	private String gradeDescription;
	private String gradeMinSalary;
	private String gradeMaxsalary;
	private List<Employee> empGradeList;
	
	
	@Id
	@Column(name="GRADE_CODE")
	public String getGradeCode() {
		return gradeCode;
	}
   public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}
   @Column(name="DESCRIPTION")
	public String getGradeDescription() {
		return gradeDescription;
	}
	public void setGradeDescription(String gradeDescription) {
		this.gradeDescription = gradeDescription;
	}
	
	@Column(name="MIN_SALARY")
	public String getGradeMinSalary() {
		return gradeMinSalary;
	}
	public void setGradeMinSalary(String gradeMinSalary) {
		this.gradeMinSalary = gradeMinSalary;
	}
	
	@Column(name="MAX_SALARY")
	public String getGradeMaxsalary() {
		return gradeMaxsalary;
	}
	public void setGradeMaxsalary(String gradeMaxsalary) {
		this.gradeMaxsalary = gradeMaxsalary;
	}
	/*
	@OneToMany(mappedBy="grade",cascade=CascadeType.ALL)*/
	/*public List<Employee> getEmpGradeList() {
		return empGradeList;
	}
	public void setEmpGradeList(List<Employee> empGradeList) {
		this.empGradeList = empGradeList;
	}*/
	@Override
	public String toString() {
		return "Grade [gradeCode=" + gradeCode + ", gradeDescription="
				+ gradeDescription + ", gradeMinSalary=" + gradeMinSalary
				+ ", gradeMaxsalary=" + gradeMaxsalary + ", empGradeList="
				+ empGradeList + "]";
	}
	
	
	
	
	
	
}
